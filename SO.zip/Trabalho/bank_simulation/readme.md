# Simulação de Conta Bancária

Este programa simula operações sobre uma conta bancária com rendimento contínuo. O saldo da conta inicia em R$100,00 e rende 1% a cada 10 segundos. O usuário pode realizar saques, depósitos, visualizar o saldo ou sair do programa.

## Como Executar

1. Certifique-se de ter o Python instalado.
2. Execute o programa com o comando:
   ```bash
   python main.py
